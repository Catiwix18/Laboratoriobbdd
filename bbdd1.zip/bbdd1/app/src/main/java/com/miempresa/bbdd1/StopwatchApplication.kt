package com.miempresa.bbdd1

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class StopwatchApplication:Application() {
}